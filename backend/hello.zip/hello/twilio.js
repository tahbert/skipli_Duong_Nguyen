const accountSid = "AC9d0ec8b2a8cd699ac92ad4a0b0e62ac5";
const authToken = "ff599bceb9cf68b94ab0d9e7f4fa62df";

const client = require('twilio')(accountSid, authToken);


module.exports = { client }